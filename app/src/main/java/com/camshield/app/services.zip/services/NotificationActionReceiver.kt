// Updated NotificationActionReceiver.kt
package com.camshield.app.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class NotificationActionReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "NotificationAction"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val notificationId = intent.getStringExtra("notification_id")
        val sosRequestId = intent.getStringExtra("sos_request_id")
        val senderName = intent.getStringExtra("sender_name")

        Log.d(TAG, "Received action: $action for notification: $notificationId")

        if (notificationId == null || sosRequestId == null) {
            Log.e(TAG, "Missing required data in notification action")
            return
        }

        // Cancel the notification immediately
        NotificationManagerCompat.from(context).cancel(1001)

        val response = when (action) {
            "ACCEPT_WALK_REQUEST" -> "accepted"
            "DECLINE_WALK_REQUEST" -> "declined"
            else -> return
        }

        // Show immediate feedback to user
        val message = if (response == "accepted") {
            "Walk request accepted! $senderName will be notified."
        } else {
            "Walk request declined."
        }

        CoroutineScope(Dispatchers.Main).launch {
            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        }

        // Handle the response asynchronously
        CoroutineScope(Dispatchers.IO).launch {
            try {
                handleWalkWithMeResponse(
                    context = context,
                    notificationId = notificationId,
                    sosRequestId = sosRequestId,
                    response = response
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error handling notification action", e)
                CoroutineScope(Dispatchers.Main).launch {
                    Toast.makeText(context, "Error processing response", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private suspend fun handleWalkWithMeResponse(
        context: Context,
        notificationId: String,
        sosRequestId: String,
        response: String
    ) {
        val auth = FirebaseAuth.getInstance()
        val firestore = FirebaseFirestore.getInstance()
        val currentUser = auth.currentUser

        if (currentUser == null) {
            Log.e(TAG, "No authenticated user")
            return
        }

        Log.d(TAG, "Processing response: $response for SOS: $sosRequestId")

        try {
            // Get current user's info
            val userDoc = firestore.collection("Users")
                .document(currentUser.uid)
                .get()
                .await()

            val responderName = userDoc.getString("name") ?: "User"
            val responderPhone = userDoc.getString("phone") ?: ""

            // Update the notification status
            firestore.collection("Notifications")
                .document(notificationId)
                .update(
                    mapOf(
                        "status" to response,
                        "responderName" to responderName,
                        "responderId" to currentUser.uid,
                        "respondedAt" to FieldValue.serverTimestamp()
                    )
                )
                .await()

            Log.d(TAG, "Notification updated: $notificationId")

            // Update the SOS request
            val updateData = mutableMapOf<String, Any>(
                "status" to if (response == "accepted") "Accepted" else "Declined",
                "respondedAt" to FieldValue.serverTimestamp()
            )

            if (response == "accepted") {
                updateData["responderId"] = currentUser.uid
                updateData["responderName"] = responderName
                updateData["responderEmail"] = currentUser.email ?: ""
                updateData["responderPhone"] = responderPhone
            }

            firestore.collection("SOS")
                .document(sosRequestId)
                .update(updateData)
                .await()

            Log.d(TAG, "SOS request updated: $sosRequestId")

            // Create a response notification for the original requester
            if (response == "accepted") {
                createResponseNotification(firestore, sosRequestId, responderName, "accepted")
            }

            Log.d(TAG, "Response handled successfully: $response by $responderName")

        } catch (e: Exception) {
            Log.e(TAG, "Error processing response", e)
            throw e
        }
    }

    private suspend fun createResponseNotification(
        firestore: FirebaseFirestore,
        sosRequestId: String,
        responderName: String,
        response: String
    ) {
        try {
            // Get the original SOS request to find the requester
            val sosDoc = firestore.collection("SOS")
                .document(sosRequestId)
                .get()
                .await()

            val requesterId = sosDoc.getString("userId")
            if (requesterId != null) {
                // Create response notification
                val responseNotificationData = mapOf(
                    "recipientUserId" to requesterId,
                    "type" to "walk_with_me_response",
                    "title" to "Walk Request Accepted!",
                    "body" to "$responderName will walk with you! They should contact you soon.",
                    "responderName" to responderName,
                    "response" to response,
                    "sosRequestId" to sosRequestId,
                    "timestamp" to FieldValue.serverTimestamp(),
                    "status" to "pending"
                )

                firestore.collection("Notifications")
                    .add(responseNotificationData)
                    .await()

                Log.d(TAG, "Response notification created for requester: $requesterId")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error creating response notification", e)
        }
    }
}