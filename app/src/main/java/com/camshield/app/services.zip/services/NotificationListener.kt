// Create this file: app/src/main/java/com/camshield/app/services/NotificationListener.kt
package com.camshield.app.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.camshield.app.MainActivity
import com.camshield.app.R
import com.camshield.app.receivers.NotificationActionReceiver
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query

class NotificationListener {
    companion object {
        private const val TAG = "NotificationListener"
        private const val CHANNEL_ID = "urgent_notifications"
        private const val WALK_WITH_ME_NOTIFICATION_ID = 1001
        private var notificationListener: ListenerRegistration? = null

        fun startListening(context: Context) {
            val auth = FirebaseAuth.getInstance()
            val firestore = FirebaseFirestore.getInstance()
            val currentUser = auth.currentUser

            if (currentUser == null) {
                Log.w(TAG, "No authenticated user, cannot start notification listener")
                return
            }

            Log.d(TAG, "Starting notification listener for user: ${currentUser.uid}")

            // Stop any existing listener
            stopListening()

            // Listen for new notifications for this user
            notificationListener = firestore.collection("Notifications")
                .whereEqualTo("recipientUserId", currentUser.uid)
                .whereEqualTo("status", "pending")
                .addSnapshotListener { snapshots, e ->
                    if (e != null) {
                        Log.w(TAG, "Listen failed.", e)
                        return@addSnapshotListener
                    }

                    if (snapshots != null && !snapshots.isEmpty) {
                        Log.d(TAG, "Received ${snapshots.documents.size} notification(s)")

                        for (doc in snapshots.documents) {
                            val notificationType = doc.getString("type")
                            Log.d(TAG, "Processing notification: ${doc.id}, type: $notificationType")

                            when (notificationType) {
                                "walk_with_me_request" -> {
                                    showWalkWithMeNotification(context, doc.data ?: emptyMap(), doc.id)
                                }
                            }
                        }
                    }
                }
        }

        fun stopListening() {
            notificationListener?.remove()
            notificationListener = null
            Log.d(TAG, "Notification listener stopped")
        }

        private fun showWalkWithMeNotification(context: Context, data: Map<String, Any>, notificationId: String) {
            val senderName = data["senderName"] as? String ?: "Someone"
            val location = data["location"] as? String ?: "Unknown location"
            val sosRequestId = data["sosRequestId"] as? String ?: ""

            Log.d(TAG, "Showing Walk With Me notification from: $senderName")

            createNotificationChannel(context)

            // Main intent when notification is tapped
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("notification_type", "walk_with_me_request")
                putExtra("notification_id", notificationId)
                putExtra("sos_request_id", sosRequestId)
            }

            val pendingIntent: PendingIntent = PendingIntent.getActivity(
                context, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            // Accept action
            val acceptIntent = Intent(context, NotificationActionReceiver::class.java).apply {
                action = "ACCEPT_WALK_REQUEST"
                putExtra("notification_id", notificationId)
                putExtra("sos_request_id", sosRequestId)
                putExtra("sender_name", senderName)
            }

            val acceptPendingIntent = PendingIntent.getBroadcast(
                context, 1, acceptIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            // Decline action
            val declineIntent = Intent(context, NotificationActionReceiver::class.java).apply {
                action = "DECLINE_WALK_REQUEST"
                putExtra("notification_id", notificationId)
                putExtra("sos_request_id", sosRequestId)
                putExtra("sender_name", senderName)
            }

            val declinePendingIntent = PendingIntent.getBroadcast(
                context, 2, declineIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            // Create the notification
            val notificationBuilder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("🚨 Walk With Me Request")
                .setContentText("$senderName needs someone to walk with them")
                .setStyle(NotificationCompat.BigTextStyle()
                    .bigText("$senderName needs someone to walk with them at $location. This is an urgent safety request. Please respond quickly."))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(false) // Don't auto-cancel so user must respond
                .setOngoing(true) // Make it persistent
                .setContentIntent(pendingIntent)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                .setVibrate(longArrayOf(0, 1000, 500, 1000, 500, 1000))
                .addAction(
                    android.R.drawable.ic_input_add,
                    "✅ Accept",
                    acceptPendingIntent
                )
                .addAction(
                    android.R.drawable.ic_delete,
                    "❌ Decline",
                    declinePendingIntent
                )
                .setFullScreenIntent(pendingIntent, true) // Shows full screen on lock screen

            try {
                with(NotificationManagerCompat.from(context)) {
                    notify(WALK_WITH_ME_NOTIFICATION_ID, notificationBuilder.build())
                }
                Log.d(TAG, "Walk With Me notification displayed successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Error showing notification", e)
            }
        }

        private fun createNotificationChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    "Urgent Safety Notifications",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Critical safety notifications for Walk With Me requests"
                    enableLights(true)
                    lightColor = android.graphics.Color.RED
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 1000, 500, 1000, 500, 1000)
                    setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), null)
                    setBypassDnd(true) // Bypass Do Not Disturb
                }

                val notificationManager: NotificationManager =
                    context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.createNotificationChannel(channel)
            }
        }
    }
}